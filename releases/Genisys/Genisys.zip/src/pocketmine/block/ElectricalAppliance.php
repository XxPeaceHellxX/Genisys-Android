<?php
/**
 * Author: PeratX
 * Time: 2015/12/13 21:22
 * Copyright(C) 2011-2015 iTX Technologies LLC.
 * All rights reserved.
 */

namespace pocketmine\block;

interface ElectricalAppliance{

}